from distutils.core import setup

setup(name='테스트',
      version='1.0',
      py_modules=['DaumAPIServer', 'Interface', 'Mail', 'Main'\
                  'MultiLineListBox','OpenAPIServer', 'XMLBook']
      )
